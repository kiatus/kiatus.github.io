Face Dancer

There isn't really much to say. Make your guy dance with his face as long as you can! You can do this by clicking on the faces coming down from the top of the screen. But avoid clicking on the sad black faces, because if you do, you lose one of your three hearts!! Losing all three will kill you. You don't want to die, do you?