Thank you for downloading the unofficial version of Nift.

Nifty was originally released by Garalina under the name Nift. This version is no longer available anywhere. If you own it, I would suggest not making it publically accessible.

Plenty of things have been altered, and it may seem a little more complex and confusing than the original. However, this one is indeed winnable.

Play this all the way through.